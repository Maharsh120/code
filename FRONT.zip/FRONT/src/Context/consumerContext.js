import { createContext, useState } from "react";

const consumerContext = createContext()

export default consumerContext